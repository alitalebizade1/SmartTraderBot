"""
main.py — SmartTraderBot (New Project / آزمایشی)
====================================================

Pipeline کامل:
    داده (yfinance) → Swing Detection → Pattern Detection (3-Touch /
    Rising-Bottom State Machine) → Signal Validation → گزارش متنی →
    چارت تعاملی HTML با نمایش کامل الگو و سیگنال خرید

این پروژه کاملاً مستقل و جدا از ریپازیتوری اصلی گیت‌هاب است.
بعد از رسیدن به نتیجه‌ی مطلوب، فایل‌ها می‌توانند جایگزین نسخه‌ی
اصلی شوند.

نحوه اجرا (روی سیستم خودتان که yfinance نصب است):
    1) نصب وابستگی‌ها از روی requirements.txt
    2) اجرای این فایل: python main.py

خروجی:
    - گزارش تحلیل کامل در ترمینال (روند، الگو، سطوح معامله)
    - فایل chart_output.html — چارت تعاملی با کندل‌ها، Swing ها،
      برخوردهای مقاومت، کف‌های صعودی (HL1/HL2)، خط شروع کانال،
      و سطوح Entry/SL/TP1/TP2 برای هر سیگنال خرید
"""
from __future__ import annotations

import webbrowser
from pathlib import Path

import pandas as pd
import yfinance as yf

from config import SYMBOL, INTERVAL, PERIOD, CHART_OUTPUT_HTML, CHART_THEME
from pattern_detector import DetectorConfig, detect
from swing_detector import SwingConfig, get_swings
from chart import build_chart, save_chart
from report import print_report


def get_data(symbol: str = SYMBOL, interval: str = INTERVAL, period: str = PERIOD) -> pd.DataFrame:
    print(f"دریافت داده {symbol} - {interval} ({period}) ...")
    raw = yf.download(
        symbol,
        interval=interval,
        period=period,
        auto_adjust=True,
        progress=False,
    )
    if raw.empty:
        raise RuntimeError(
            "داده‌ای دریافت نشد. نماد/تایم‌فریم/بازه را بررسی کنید "
            "(yfinance محدودیت 60 روز اخیر برای تایم‌فریم 15 دقیقه دارد)."
        )

    raw.columns = [
        c[0].lower() if isinstance(c, tuple) else c.lower()
        for c in raw.columns
    ]
    raw = raw[["open", "high", "low", "close"]].dropna().reset_index()
    raw.rename(columns={raw.columns[0]: "time"}, inplace=True)
    print(f"تعداد کندل دریافت‌شده: {len(raw)}")
    print(f"بازه زمانی: {raw['time'].iloc[0]}  →  {raw['time'].iloc[-1]}")
    return raw


def main() -> None:
    print("=" * 72)
    print(" SmartTraderBot — نسخه جدید (3-Touch Resistance / Rising-Bottom)")
    print("=" * 72)

    df = get_data()

    swing_cfg = SwingConfig()
    swings = get_swings(df, swing_cfg)

    detector_cfg = DetectorConfig(swing_cfg=swing_cfg)
    signals = detect(df, detector_cfg)

    print_report(signals, swings_count=len(swings), candles_count=len(df))

    fig = build_chart(df, swings, signals, theme=CHART_THEME)
    out_path = Path(CHART_OUTPUT_HTML).resolve()
    save_chart(fig, str(out_path))
    print(f"\n چارت تعاملی ذخیره شد: {out_path}")
    print(" برای مشاهده، فایل را در مرورگر باز کنید.")

    try:
        webbrowser.open(f"file://{out_path}")
    except Exception:
        pass


if __name__ == "__main__":
    main()
